console.log("Hola desde javascript")
alert("JOrdy")